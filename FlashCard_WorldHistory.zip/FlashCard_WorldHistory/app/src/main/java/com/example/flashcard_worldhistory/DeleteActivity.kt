package com.example.flashcard_worldhistory

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class DeleteActivity : AppCompatActivity() {

    private val sqLite: SQLite = SQLite(this)
    private var db: SQLiteDatabase = sqLite.readableDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delete)


        val sql = "SELECT * FROM MyTable ORDER BY Word ASC"
        val c: Cursor = db.rawQuery(sql,null)

        val word2 = findViewById<TextView>(R.id.word2)
        val description2 = findViewById<TextView>(R.id.description2)

        val delete2 = findViewById<Button>(R.id.delete2)
        val back2 = findViewById<Button>(R.id.back)

        c.moveToPosition(EditActivity.DATA_position)

        val word = c.getString(c.getColumnIndex("Word"))
        val mean = c.getString(c.getColumnIndex("Mean"))

        word2.text = word
        description2.text = mean

        c.close()
        db.close()

        delete2.setOnClickListener {
            db = sqLite.writableDatabase
            db.delete("MyTable", "Word = '$word'", null)

            finish()
        }

        back2.setOnClickListener {
            c.close()
            db.close()

            val intent = Intent(application, MainActivity::class.java)
            startActivity(intent)

            finish()
        }
    }
}