package com.example.flashcard_worldhistory

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.widget.Button
import android.widget.EditText

class AddActivity : AppCompatActivity() {

    private val sqLite: SQLite = SQLite(this)
    private val db: SQLiteDatabase = sqLite.readableDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        val word: EditText = findViewById(R.id.word)
        val description: EditText = findViewById(R.id.description)
        val delete: Button = findViewById(R.id.delete)
        val save: Button = findViewById(R.id.save)
        val back: Button = findViewById(R.id.back)

        delete.setOnClickListener {
            word.setText("")
            description.setText("")
        }

        save.setOnClickListener {
            val sbWord = word.text as SpannableStringBuilder
            Word_Add = sbWord.toString()
            val sbMean = description.text as SpannableStringBuilder
            Mean_Add = sbMean.toString()

            if (Word_Add != "" && Mean_Add != "") {

                sqLite.saveData(db)

                word.setText("")
                description.setText("")

            } else if (Word_Add == "" && Mean_Add != "") {

                word.setText("入力してください")

            } else if (Word_Add != "") {

                description.setText("入力してください")

            } else {

                word.setText("入力してください")
                description.setText("入力してください")

            }
        }


        back.setOnClickListener {
            val intent = Intent(application, MainActivity::class.java)
            startActivity(intent)

            finish()
        }
    }

    companion object {

        var Word_Add: String = ""
        var Mean_Add: String = ""

    }
}
