package com.example.flashcard_worldhistory

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class SelectActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select)

        val button1 = findViewById<Button>(R.id.Continuity)
        val button2 = findViewById<Button>(R.id.Randomly)

        canClick_Select = true

        button1.setOnClickListener {
            if (canClick_Select) {
                val intent1 = Intent(application, VocabularyActivity::class.java)
                data_Order = true
                canClick_Select = false
                startActivity(intent1)
                finish()
            }
        }

        button2.setOnClickListener {
            if (canClick_Select) {
                val intent2 = Intent(application, VocabularyActivity::class.java)
                data_Order = false
                canClick_Select = false
                startActivity(intent2)
                finish()
            }
        }
    }

    companion object {

        var data_Order: Boolean = false
        var canClick_Select: Boolean = false
    }
}
