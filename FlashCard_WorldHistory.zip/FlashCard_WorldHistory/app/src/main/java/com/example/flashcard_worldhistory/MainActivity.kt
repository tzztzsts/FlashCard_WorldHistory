package com.example.flashcard_worldhistory

import android.content.Intent
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val check = findViewById<Button>(R.id.Check)
        val edit = findViewById<Button>(R.id.Edit)
        val finish = findViewById<Button>(R.id.Finish)

        val sqLite = SQLite(this)
        val db: SQLiteDatabase = sqLite.readableDatabase

        val quantity = DatabaseUtils.queryNumEntries(db, "MyTable")

        if (quantity == 0L) {
            check.setBackgroundColor(Color.rgb(68, 68, 68))
            check.isEnabled = false
        } else {
            check.setBackgroundColor(Color.rgb(255, 216, 27))
            check.isEnabled = true
        }


        check.setOnClickListener {
            val intent = Intent(application, SelectActivity::class.java)
            startActivity(intent)
        }

        edit.setOnClickListener {
            val intent = Intent(application, EditActivity::class.java)
            startActivity(intent)
            finish()
        }

        finish.setOnClickListener { finish() }
    }
}
