package com.example.flashcard_worldhistory

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class SQLite internal constructor(context: Context) : SQLiteOpenHelper(context, "SQLite.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL("CREATE TABLE MyTable" +
                "(" +
                "Word TEXT" +
                ", Mean TEXT" +
                ")")

    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

        db.execSQL("DROP TABLE IF EXISTS MyTable")
        onCreate(db)

    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

        onUpgrade(db, oldVersion, newVersion)

    }

    fun saveData(db: SQLiteDatabase) {

        val values = ContentValues()
        values.put("Word", AddActivity.Word_Add)
        values.put("Mean", AddActivity.Mean_Add)
        db.insert("MyTable", null, values)

    }
}