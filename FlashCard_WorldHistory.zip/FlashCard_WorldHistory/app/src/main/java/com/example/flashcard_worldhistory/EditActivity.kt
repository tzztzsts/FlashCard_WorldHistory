package com.example.flashcard_worldhistory

import android.content.Intent
import android.database.Cursor
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView

class EditActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        var canClickEdit = true

        val sqLite = SQLite(this)
        val db: SQLiteDatabase = sqLite.readableDatabase
        val sql = "SELECT * FROM MyTable ORDER BY Word ASC"
        val c: Cursor = db.rawQuery(sql,null)

        val listView = ListView(this)

        setContentView(listView)

        val quantity = DatabaseUtils.queryNumEntries(db, "MyTable")

        val intQuantity = quantity.toInt()

        if (intQuantity >= 1) {

            val words = arrayOfNulls<String>(intQuantity + 1)

            words[0] = "ここを押すと単語を追加できます"

            for (i in 0 until words.size - 1) {

                c.moveToPosition(i)
                words[i + 1] = c.getString(c.getColumnIndex("Word"))

            }

            val arrayAdapter: ArrayAdapter<String?> = ArrayAdapter(this, android.R.layout.simple_list_item_1, words)
            listView.adapter = arrayAdapter

        } else {

            val words = arrayOfNulls<String?>(1)
            words[0] = "単語が登録されていません（ここを押して単語を追加）"

            val arrayAdapter: ArrayAdapter<String?> = ArrayAdapter(this, android.R.layout.simple_list_item_1, words)
            listView.adapter = arrayAdapter

        }

        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            if (canClickEdit) {

                canClickEdit = false

                if (position == 0) {

                    val intent = Intent(application, AddActivity::class.java)
                    startActivity(intent)

                } else {

                    DATA_position = position - 1
                    val intent = Intent(application, DeleteActivity::class.java)
                    startActivity(intent)

                }

                c.close()
                db.close()
                finish()

            }
        }
    }

    companion object {

        var DATA_position: Int = 0
    }
}