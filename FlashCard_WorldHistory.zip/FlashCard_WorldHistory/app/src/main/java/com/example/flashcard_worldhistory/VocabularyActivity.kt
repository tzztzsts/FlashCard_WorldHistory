package com.example.flashcard_worldhistory

import android.database.Cursor
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.util.*

class VocabularyActivity : AppCompatActivity() {

    private val sqLite: SQLite = SQLite(this)
    private val db: SQLiteDatabase = sqLite.readableDatabase
    private val sql: String = "SELECT * FROM MyTable ORDER BY Word ASC"
    private val c: Cursor = db.rawQuery(sql,null)

    private var word: String = ""
    private var mean: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vocabulary)



        var units = 0
        var rnd = 0
        var rnd2: Int

        var ansOrNext = true
        var continuous: Boolean

        val question: TextView = findViewById(R.id.question)
        val answer: TextView = findViewById(R.id.answer)
        val next: Button = findViewById(R.id.Next2)
        val back: Button = findViewById(R.id.back3)

        val random = Random()

        if (SelectActivity.data_Order) {

            c.moveToFirst()

        } else {

            units = DatabaseUtils.queryNumEntries(db, "MyTable").toInt()
            rnd = random.nextInt(units)
            c.moveToPosition(rnd)

        }

        getWordAndMean()

        question.text = mean

        next.setOnClickListener {
            if (ansOrNext) {

                answer.text = word
                ansOrNext = false

            } else {

                if (SelectActivity.data_Order) {

                    if (c.moveToNext()) {

                        getWordAndMean()

                    } else {

                        c.moveToFirst()
                        getWordAndMean()

                    }

                } else {

                    do
                    {
                        rnd2 = random.nextInt(units)

                        var times = 0
                        times++
                        continuous = rnd == rnd2

                        if (times == 3) {

                            break

                        }
                    }
                    while (continuous)

                    rnd = rnd2

                    c.moveToPosition(rnd)

                    getWordAndMean()

                }

                question.text = mean
                answer.text = ""
                ansOrNext = true

            }
        }

        back.setOnClickListener {
            c.close()
            db.close()
            finish()
        }
    }

    private fun getWordAndMean() {

        word = c.getString(c.getColumnIndex("Word"))
        mean = c.getString(c.getColumnIndex("Mean"))

    }
}
